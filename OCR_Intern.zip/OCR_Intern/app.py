import os  
from flask import Flask, render_template, request
from werkzeug.utils import secure_filename

# import our OCR function
from mavoix import mavoix

# define a folder to store and later serve the images
UPLOAD_FOLDER = '/static/uploads/'

# allow files of a specific type
ALLOWED_EXTENSIONS = set(['txt'])

app = Flask(__name__)

# function to check the file extension
def allowed_file(filename):  
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

# route and function to handle the home page
#@app.route('/')
#def home_page():  
    #return render_template('index.html')

# route and function to handle the upload page
@app.route('/', methods=['GET', 'POST'])
def upload_page():  
    if request.method == 'POST':
        # check if there is a file in the request
        if 'dc1' not in request.files or 'dc2' not in request.files:
            return render_template('upload.html', msg='MC')
        file1 = request.files['dc1']
        file2 = request.files['dc2']
        # if no file is selected
        if file1.filename == '' or file2.filename== '':
            return render_template('upload.html', msg='BC')

        if file1 and allowed_file(file1.filename) and file2 and allowed_file(file2.filename):

            # call the OCR function on it
            #file1.save(os.path.join(UPLOAD_FOLDER, file1.filename))
            

            file1.save(file1.filename)
            file2.save(file1.filename)
            #file2.save(os.path.join(UPLOAD_FOLDER, file2.filename))
            extracted_text = mavoix(UPLOAD_FOLDER + file1.filename )

            # extract the text and display it
            return render_template('upload.html',
                                   msg='Successfully processed',
                                   extracted_text=extracted_text,
                                   img_src=UPLOAD_FOLDER + file1.filename)
    elif request.method == 'GET':
        return render_template('upload.html')

if __name__ == '__main__':  
    app.run()
