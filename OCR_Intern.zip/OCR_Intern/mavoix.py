
try:  
    from PIL import Image
except ImportError:  
    import Image
import pytesseract

def mavoix(filename):
    print("MC")
    print(filename)
    code = open(filename, 'r').read()
    return code 
    

